# SHC - Icon folder
This is a folder only reserved for official icons, not assets, not addicional, only favicons and icons.
Supported: .png, .ico, .svg