# Special THANKS!!
for all of those who contributed to this project, even if just a idea, rating or a word. You mean a lot to me and should be on **a pedestal.**

## @Dhummy - My bestie
Designer • Creative Ideas • Motivation
> Helped-me personally design some of the new features of OceanBoard, on the app and documentation.

Socials: [Discord](https://discord.com/users/1039935490612265020), [Github](https://github.com/dhummy)

## @ShiTist -
Supporter • Motivation • Tester
> Thank-u for the kind words.. you made me cry of happiness.

## @doop -
Tester
> You destroyed the version 0.0.4 in front of me. RAW. Laughing to not cry hahah.. well thanks! 💛

## @DevilWolf
Supporter
> Your words are always amazing, thanks for being by my side to see my projects.

Socials: [Website](https://wiki-page-devilwolf.netlify.app/)

# oceanboard
created by [umaera](https://umaera.github.io/social/)

made for the world and developed by you.