# Docs - Documentation folder
Just write simple and user-friendly .md files explaining each thing/feature/concept!