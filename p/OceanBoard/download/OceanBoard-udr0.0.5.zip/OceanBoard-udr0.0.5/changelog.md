# Changelog!!!! yayyyyy partieess

## udr 0.0.5
> "Oh Memory, Oh Mobile, Oh commands, Oh my!"
- Added translation support
- Added LZ-String Lib for localstorage compression.
- Improved memory manangement, don't worry - your data will migrate to the new format.
- Changed Lib files to have a readable structure + the credits, 'cause we not stealing.
- Improved error handling, now you can see errors.
- Improved visual feedback, now you can see loading bars to indicate the process.
- Added Shortcuts - Finally HERE!! learn how to use in: [docs/keyboard-shortcuts](https://umaera.github.io/OceanBoard/docs/#keyboard-shortcuts)
- Added Command Palette - YUPPIE!! Now every action is smooth like butter, learn how to use in: [docs/command-palette](https://umaera.github.io/OceanBoard/docs/#command-palette)
- Added live word stats, you can see the words/chars/minutes read.
- Added ANIMATIONS EVERYWHERE!!!
- Added manifest to the website, now the internet can know about the website, and you can install this as an chrome app on mobile.. speaking of mobile:
- Added MOBILE/TABLET SUPPORT!!!11!!

## udr 0.0.4
- All and nothing was created, humble starting point. Check: https://umaera.github.io/OceanBoard